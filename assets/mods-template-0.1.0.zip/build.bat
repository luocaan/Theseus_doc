@echo off
setlocal enabledelayedexpansion
rem ================================================================
rem  SEECMD Mod One-Click Build (no Maven required)
rem
rem  Usage:
rem    1. Put this script in your mod project root folder.
rem    2. Download mod-api-*.jar from the game release page and put it
rem       next to this script (or set API_JAR manually below).
rem    3. Put Java sources under src\main\java, resources (images/audio)
rem       under src\main\resources.
rem    4. Edit the 4 MOD_* variables below to match your mod.
rem    5. Double-click this script. The mod jar appears in target\.
rem
rem  NOTE: keep this file pure ASCII (avoid non-ASCII comments) so it
rem  parses correctly on any Windows codepage.
rem ================================================================

rem ---- Edit these 4 lines to match your mod ----
set "MOD_ID=example_mod"
set "MOD_NAME=Example Mod"
set "MOD_VERSION=0.1.0"
set "MOD_CLASS=com.example.mymod.ExampleMod"
rem ------------------------------------------------

rem ---- Optional: set API_JAR manually if auto-detect fails ----
rem set "API_JAR=mod-api-0.6.7.jar"

rem Always run from the script's own folder (supports double-click)
cd /d "%~dp0"

set "SRC_DIR=src\main\java"
set "RES_DIR=src\main\resources"
set "OUT_DIR=target\classes"

rem ---- Locate mod-api jar ----
set "API_JAR="
for %%f in (mod-api-*.jar) do set "API_JAR=%%f"
if not defined API_JAR (
    echo [ERROR] mod-api-*.jar not found in this folder.
    echo         Download it from the game release page and put it here,
    echo         or set API_JAR manually at the top of this script.
    exit /b 1
)
echo [INFO] Using API jar: %API_JAR%

if not exist "%SRC_DIR%" (
    echo [ERROR] Cannot find %SRC_DIR%. Run this script from the mod project root.
    exit /b 1
)

rem ---- 1. clean and compile ----
if exist target rmdir /s /q target
mkdir "%OUT_DIR%" 2>nul

echo [1/4] Compiling sources...
powershell -NoProfile -Command "Get-ChildItem -Path '%SRC_DIR%' -Recurse -Filter *.java | ForEach-Object { $_.FullName.Replace('\','/') } | Out-File -FilePath 'target\srcfiles.txt' -Encoding ascii"
javac --release 17 -encoding UTF-8 -cp "%API_JAR%" -d "%OUT_DIR%" "@target\srcfiles.txt"
if errorlevel 1 (
    echo [ERROR] Compilation failed. See messages above.
    exit /b 1
)

rem ---- 2. copy resources ----
if exist "%RES_DIR%" (
    echo [2/4] Copying resources...
    xcopy /e /i /y /q "%RES_DIR%" "%OUT_DIR%" >nul
)

rem ---- 3. write manifest ----
echo [3/4] Writing manifest...
> "target\manifest.mf" (
    echo Manifest-Version: 1.0
    echo Seecmd-Mod-Class: %MOD_CLASS%
    echo Seecmd-Mod-Id: %MOD_ID%
    echo Seecmd-Mod-Name: %MOD_NAME%
    echo Seecmd-Mod-Version: %MOD_VERSION%
    echo Seecmd-Mod-Authors: %USERNAME%
    echo Seecmd-Mod-Description: SEECMD mod %MOD_ID% v%MOD_VERSION%
)

rem ---- 4. package jar ----
echo [4/4] Packaging jar...
jar cfm "target\%MOD_ID%-%MOD_VERSION%.jar" "target\manifest.mf" -C "%OUT_DIR%" .
if errorlevel 1 (
    echo [ERROR] Packaging failed.
    exit /b 1
)

echo.
echo [DONE] Build finished: target\%MOD_ID%-%MOD_VERSION%.jar
echo        Copy this jar into the game's mods\ folder and start the game.
echo.
endlocal
