package com.example.mymod;

import com.seecmd.mod.api.GameplayMod;
import com.seecmd.mod.api.ModContext;
import com.seecmd.mod.api.ModInfo;
import java.util.List;

/**
 * 模组示例入口类。
 *
 * <p>实现 {@link GameplayMod}（或仅实现 {@link com.seecmd.mod.api.Mod}）即可被游戏加载。
 * 打包后 jar 的 manifest 必须声明 {@code Seecmd-Mod-Class} 指向本类
 * （模板的 build.bat 与 pom.xml 已配置好，改类名时同步修改即可）。
 *
 * <p>所有注册钩子（渲染滤镜 / 判定策略 / 事件订阅等）均为默认空实现，
 * 模组按需覆写，见各方法的 javadoc。
 */
public final class ExampleMod implements GameplayMod {

    @Override
    public ModInfo info() {
        return ModInfo.of(
                "example_mod",              // 模组 id：小写下划线，全局唯一，勿与内置/他人模组冲突
                "Example Mod",              // 显示名称
                "0.1.0",                    // 版本号
                List.of("YourName"),        // 作者列表
                "我的第一个 SEECMD 模组");   // 描述
    }

    @Override
    public void onLoad(ModContext ctx) {
        // 初始化入口：读取配置（ctx.config()）、注册音频（ctx.registerSound 等）、
        // 注册收集品（ctx.unlockCollect）、访问四大注册表（ctx.judgmentKinds() 等）。
        ctx.getLogger().info("ExampleMod 已加载");
        // 向玩家展示提示：toast 数秒后自动消失；重要信息可用 ctx.notifier().dialog("...", 5000)
        ctx.notifier().info("Example Mod 已加载");
    }
}
