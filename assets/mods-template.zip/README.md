# SEECMD 模组模板工程

这是第三方模组开发的最小模板，提供两种构建方式，任选其一：

## 方式一：一键构建（无需 Maven，推荐）

1. 从游戏发布页下载 `mod-api-0.7.0.jar`，放到本目录（与 `build.bat` 同级）。
2. 编辑 `build.bat` 顶部的 4 个变量：`MOD_ID`、`MOD_NAME`、`MOD_VERSION`、`MOD_CLASS`。
3. 在 `src\main\java` 下写代码，在 `src\main\resources` 下放图片/音频资源。
4. 双击 `build.bat`，产物在 `target\<MOD_ID>-<MOD_VERSION>.jar`。

要求：本机已安装 JDK 17+，且 `javac`、`jar` 在 PATH 中（安装 JDK 时勾选即可）。

## 方式二：Maven 构建

1. 先把 API jar 安装进本地仓库（只需一次）：

   ```
   mvn install:install-file -Dfile=mod-api-0.7.0.jar ^
     -DgroupId=com.seecmd -DartifactId=mod-api -Dversion=0.7.0 -Dpackaging=jar
   ```

2. 修改 `pom.xml` 中的坐标与 manifest 字段，执行：

   ```
   mvn package
   ```

   产物在 `target\example-mod-0.1.0.jar`。

## 安装到游戏

把打好的 jar 放入游戏的 `mods\` 目录，启动游戏即可自动加载。

## 说明

- manifest 中 `Seecmd-Mod-Class` 是必须的（指向你的入口类），
  其余 `Seecmd-Mod-Id/Name/Version/Authors/Description` 供管理工具展示，建议都填。
- 模组 id 只允许字母、数字、下划线、连字符，且被用于 `data/mods/<id>` 数据目录。
- 示例入口 `ExampleMod` 只实现了 `info()` 与 `onLoad()`，
  更完整的能力（打击特效 / 渲染滤镜 / 判定调整 / 事件订阅 / 能力注入）见开发文档：
  - 模组开发指南（mod-guide）
  - 模组 API 参考（mod-api）
